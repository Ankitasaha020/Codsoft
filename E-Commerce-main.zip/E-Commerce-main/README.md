
# E-Commerce
Problem Statement
Hi, My name is Amit. I am the Owner of a product-based company
where I sell Electronics Appliance. I want to shift my company to the
online . I Want to hire a web developer for my company. If you are
interested then you have to complete below tasks.
You have to design a website with the following specification:-
1. Develop a login/registration panel where two types of customer
registration will be available
a. For Individual Person
b. For an Company/Organization
2. If a user is buying product using his organization’s registartion
he/she had to provide employee details and also have to provide the
information that the product being bought is for the company use or
the employer’s. In both the cases organization will pay the bills.
3. Design an admin panel where you have to show which products
are bought by an individual person or a company/organization.
4. In the company you have to show which products are bought for a
company or bought by an individual employee with employee detail.
Example:
Consider Riteh Singh Registered as Individual person then Riteh can
shop products normally and all his registration info can be used for
orders and delivery. Also when Amit (Owner of Shop) logged in and
opens his Admin Panel he can see products bought by Riteh.
Now consider another situation where PCC registered for the shop as
organization and Riteh and Aayush are the two employees in the
organization. Then while registering PCC has to provide their
employee details who will be elegible to buy products as
organization members.
Now when Riteh or Aayush login with their organization code and
their details (Employee ID is must) they are allowed to shop but
when placing the order they will asked if that order is placed for their
use or organizational use. Now when the shop owner Amit logged in
into his account and open his admin panel he can see all the
individual customers like Riteh,Sumit,Aman etc. and also
organizational customers like PCC,OSOC etc. But when Amit clicks in
PCC he should be showed all the products bought via organization
and which product is bought by which employee and for personal
use or organizational use.

